package hu.bme.aut.rainbowcakedemo.ui

import co.zsmb.rainbowcake.withIOContext
import javax.inject.Inject

class MainScreenPresenter @Inject constructor() {
    fun getMoneyResult() {

    }
}
